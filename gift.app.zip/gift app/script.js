// ===============================
// Loading Screen
// ===============================

window.onload = function () {

    setTimeout(function () {

        document.getElementById("loadingScreen").style.display = "none";
        document.getElementById("welcomeCard").style.display = "block";

    }, 3000);

};

// ===============================
// Variables
// ===============================

let inputs = [];
let index = 0;
let currentScreen = "welcome";

// ===============================
// Open Gift
// ===============================

function startGift() {

    document.getElementById("welcomeCard").style.display = "none";
    document.getElementById("pinScreen").style.display = "flex";

    currentScreen = "pin";
    showBackButton();

    inputs = [
        document.getElementById("p1"),
        document.getElementById("p2"),
        document.getElementById("p3"),
        document.getElementById("p4")
    ];

    index = 0;

    inputs.forEach(input => input.value = "");

    document.getElementById("msg").innerHTML = "";

}

// ===============================
// Keypad
// ===============================

function press(num) {

    if (index < 4) {

        inputs[index].value = num;
        index++;

    }

}

function clearPin() {

    if (index > 0) {

        index--;
        inputs[index].value = "";

    }

}

// ===============================
// Check Passcode
// ===============================

function checkPin() {

    let pin = "";

    inputs.forEach(input => pin += input.value);

    if (pin === "1430") {

        document.getElementById("pinScreen").style.display = "none";
        document.getElementById("birthdayScreen").style.display = "flex";

        currentScreen = "birthday";

    } else {

        showWrongScreen();

    }

}
// ===============================
// Wrong Screen
// ===============================

function showWrongScreen() {

    document.getElementById("pinScreen").style.display = "none";
    document.getElementById("wrongScreen").style.display = "flex";

    currentScreen = "wrong";

}

function tryAgain() {

    document.getElementById("wrongScreen").style.display = "none";
    document.getElementById("pinScreen").style.display = "flex";

    inputs.forEach(input => input.value = "");
    index = 0;

    document.getElementById("msg").innerHTML = "";

    currentScreen = "pin";

}

// ===============================
// Birthday → Cake
// ===============================

function goCake() {

    document.getElementById("birthdayScreen").style.display = "none";
    document.getElementById("cakeScreen").style.display = "flex";

    currentScreen = "cake";

    document.getElementById("cakeImg").src = "IMAGES/eyeg.png";

    document.querySelector(".cake-card p").innerHTML =
        "🎉 Make a wish and cut the cake! 💖";

    document.querySelector(".cut-btn").style.display = "inline-block";

}

// ===============================
// Cut Cake
// ===============================

function cutCake() {

    document.getElementById("cakeImg").src = "IMAGES/cake-cut.png";

    document.querySelector(".cake-card p").innerHTML =
        "🎉 Cake Cut Successfully! Happy Birthday 💖";

    document.querySelector(".cut-btn").style.display = "none";

    setTimeout(function () {

        document.getElementById("cakeScreen").style.display = "none";
        document.getElementById("giftScreen").style.display = "flex";

        currentScreen = "gift";

    }, 2500);

}
// ===============================
// Gift Screen
// ===============================

function openGift() {

    document.getElementById("giftScreen").style.display = "none";
    document.getElementById("letterScreen").style.display = "flex";

    currentScreen = "letter";

}

// ===============================
// Memories Gallery
// ===============================

let photos = [
    "IMAGES/photo1.jpg",
    "IMAGES/photo2.jpg",
    "IMAGES/photo3.jpg",
    "IMAGES/photo4.jpg",
    "IMAGES/photo5.jpg"
];

let photoIndex = 0;

// ===============================
// Letter → Memories
// ===============================

function nextMemories() {

    document.getElementById("letterScreen").style.display = "none";
    document.getElementById("memoryScreen").style.display = "flex";

    currentScreen = "memory";

    photoIndex = 0;
    document.getElementById("memoryImg").src = photos[photoIndex];

}

// ===============================
// Next Photo
// ===============================

function nextPhoto() {

    photoIndex++;

    if (photoIndex >= photos.length) {

        document.getElementById("memoryScreen").style.display = "none";
        document.getElementById("finalScreen").style.display = "flex";

        currentScreen = "final";
        return;

    }

    document.getElementById("memoryImg").src = photos[photoIndex];

}

// ===============================
// Previous Photo
// ===============================

function prevPhoto() {

    photoIndex--;

    if (photoIndex < 0) {

        photoIndex = photos.length - 1;

    }

    document.getElementById("memoryImg").src = photos[photoIndex];

}
// ===============================
// Back Button
// ===============================

function showBackButton() {
    document.getElementById("backBtn").style.display = "flex";
}

function hideBackButton() {
    document.getElementById("backBtn").style.display = "none";
}

function goBack() {

    switch (currentScreen) {

        case "pin":
            document.getElementById("pinScreen").style.display = "none";
            document.getElementById("welcomeCard").style.display = "block";
            currentScreen = "welcome";
            hideBackButton();
            break;

        case "wrong":
            document.getElementById("wrongScreen").style.display = "none";
            document.getElementById("pinScreen").style.display = "flex";
            currentScreen = "pin";
            break;

        case "birthday":
            document.getElementById("birthdayScreen").style.display = "none";
            document.getElementById("pinScreen").style.display = "flex";
            currentScreen = "pin";
            break;

        case "cake":
            document.getElementById("cakeScreen").style.display = "none";
            document.getElementById("birthdayScreen").style.display = "flex";
            currentScreen = "birthday";
            break;

        case "gift":
            document.getElementById("giftScreen").style.display = "none";
            document.getElementById("cakeScreen").style.display = "flex";
            currentScreen = "cake";
            break;

        case "letter":
            document.getElementById("letterScreen").style.display = "none";
            document.getElementById("giftScreen").style.display = "flex";
            currentScreen = "gift";
            break;

        case "memory":
            document.getElementById("memoryScreen").style.display = "none";
            document.getElementById("letterScreen").style.display = "flex";
            currentScreen = "letter";
            break;

        case "final":
            document.getElementById("finalScreen").style.display = "none";
            document.getElementById("memoryScreen").style.display = "flex";
            currentScreen = "memory";
            break;
    }

}

// ===============================
// Floating Hearts
// ===============================

setInterval(createHeart, 500);

function createHeart() {

    const heart = document.createElement("div");

    heart.className = "heart";
    heart.innerHTML = "💖";

    heart.style.left = Math.random() * 100 + "vw";
    heart.style.fontSize = (20 + Math.random() * 20) + "px";

    document.getElementById("floatingHearts").appendChild(heart);

    setTimeout(() => heart.remove(), 6000);

}

// ===============================
// Touch Hearts
// ===============================

document.addEventListener("click", function (e) {

    const heart = document.createElement("div");

    heart.className = "heart";
    heart.innerHTML = "💖";

    heart.style.left = e.clientX + "px";
    heart.style.top = e.clientY + "px";
    heart.style.bottom = "auto";
    heart.style.fontSize = "30px";

    document.getElementById("floatingHearts").appendChild(heart);

    setTimeout(() => heart.remove(), 3000);

});

// ===============================
// Replay
// ===============================

function replaySurprise() {
    location.reload();
}
document.addEventListener("touchmove", function(e) {
    e.preventDefault();
}, { passive: false });
